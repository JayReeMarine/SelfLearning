package com.fit2081.week3_lab_30324181;

public class Item {

    private String result;


    public Item(String result) {
        this.result = result;
    }

    public String getResult() {
        return result;
    }

}

