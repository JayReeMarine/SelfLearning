package com.fit2081.a1_30324181;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import java.util.Random;

import java.util.StringTokenizer;

public class invoiceGenerator extends AppCompatActivity {

    EditText issuerName, buyerName, buyerAddress, itemName, itemQuantity, itemCost;
    Switch isPaid;
    SharedPreferences sP;
    final String INVOICE_PREF = "InvoicePref";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice_generator);

        issuerName = findViewById(R.id.issuerName);
        buyerName = findViewById(R.id.buyerName);
        buyerAddress = findViewById(R.id.buyerAddress);
        isPaid = findViewById(R.id.paidSwitch);
        itemName = findViewById(R.id.itemName);
        itemQuantity = findViewById(R.id.itemQuantity);
        itemCost = findViewById(R.id.itemCost);


        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS, android.Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 0);

        sP = getSharedPreferences(INVOICE_PREF, MODE_PRIVATE);

        MyCustomBroadcastReceiver myCustomBroadcastReciever = new MyCustomBroadcastReceiver();
        registerReceiver(myCustomBroadcastReciever, new IntentFilter(SMSReciever.SMS_FILTER),RECEIVER_EXPORTED);


    }

    class MyCustomBroadcastReceiver  extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra(SMSReciever.SMS_MSG_KEY);

            String[] parts = msg.split(":", 2);
            if (parts.length < 2) {
                Toast.makeText(context, "Invalid command format", Toast.LENGTH_SHORT).show();
                return;
            }

            String command = parts[0].toLowerCase();
            String details = parts[1];

            StringTokenizer sT = new StringTokenizer(details, ";");

            switch (command) {
                case "invoice":
                    if (sT.countTokens() >= 4) {
                        issuerName.setText(sT.nextToken());
                        buyerName.setText(sT.nextToken());
                        buyerAddress.setText(sT.nextToken());
                        isPaid.setChecked("true".equalsIgnoreCase(sT.nextToken()));
                    } else {
                        Toast.makeText(invoiceGenerator.this, "Incomplete invoice data", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case "item":
                    if (sT.countTokens() >= 3) {
                        itemName.setText(sT.nextToken());
                        itemQuantity.setText(sT.nextToken());
                        itemCost.setText(sT.nextToken());
                    } else {
                        Toast.makeText(invoiceGenerator.this, "Incomplete item data", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case "save":
                    if (sT.hasMoreTokens() && "invoice".equals(sT.nextToken())) {
                        try {
                            saveInvoiceData();
                        } catch (Exception e) {
                            Toast.makeText(invoiceGenerator.this, "Please fill out the information properly.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    break;

                case "load":
                    if (sT.hasMoreTokens() && "invoice".equals(sT.nextToken())) {
                        loadInvoiceData();
                    }
                    break;
                default:
                    Toast.makeText(context, "Unrecognized command", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void logOutBtn(View view){
        Intent intent = new Intent(this, loginPage.class);
        startActivity(intent);
    }

    public void saveInvoiceBtn(View view){
        saveInvoiceData();
    }



    private void saveInvoiceData() {
        String invoiceId = generateId("invoice", "");
        String buyerId = generateId("buyer", buyerName.getText().toString());
        String itemId = generateId("item", itemName.getText().toString());
        SharedPreferences.Editor editor = sP.edit();


        editor.putString("IssuerName", issuerName.getText().toString());
        editor.putString("BuyerName", buyerName.getText().toString());
        editor.putString("BuyerAddress", buyerAddress.getText().toString());
        editor.putBoolean("IsPaid", isPaid.isChecked());
        editor.putString("ItemName", itemName.getText().toString());
        editor.putInt("ItemQuantity", Integer.parseInt(itemQuantity.getText().toString()));
        editor.putFloat("ItemCost", Float.parseFloat(itemCost.getText().toString()));

        editor.apply();
        Toast.makeText(this, "Invoice ID: " + invoiceId + "\nBuyer ID: " + buyerId + "\nItem ID: " + itemId, Toast.LENGTH_LONG).show();


        //Total Value and items

        int itemQuantityValue = Integer.parseInt(itemQuantity.getText().toString());
        float itemCostValue = Float.parseFloat(itemCost.getText().toString());
        float totalValue = itemQuantityValue * itemCostValue;
        editor.putFloat("TotalValue", totalValue);
        editor.putString("Items", itemName.getText().toString());


        //reset the initial value
        issuerName.setText("");
        buyerName.setText("");
        buyerAddress.setText("");
        isPaid.setChecked(false);
        itemName.setText("");
        itemQuantity.setText("");
        itemCost.setText("");

    }


    private String generateId(String type, String name) {
        final Random random = new Random();
        StringBuilder id = new StringBuilder();

        try {
            switch (type) {
                case "invoice":
                    id.append("I");
                    for (int i = 0; i < 2; i++) {
                        id.append((char) (random.nextInt(26) + 'A')); // Directly appending ASCII character
                    }
                    id.append("-");
                    for (int i = 0; i < 4; i++) {
                        id.append(random.nextInt(10));
                    }
                    break;
                case "buyer":
                    id.append("B").append(name.substring(0, 2));
                    id.append("-");
                    for (int i = 0; i < 3; i++) {
                        id.append(random.nextInt(10));
                    }
                    break;
                case "item":
                    id.append("T").append(name.substring(0, 2));
                    id.append("-");
                    for (int i = 0; i < 4; i++) {
                        id.append(random.nextInt(10));
                    }
                    break;
            }
        } catch (StringIndexOutOfBoundsException e) {
            Toast.makeText(getApplicationContext(), "Missing required name for " + type + " ID generation.", Toast.LENGTH_SHORT).show();
        }
        return id.toString();
    }


    private void loadInvoiceData() {
        // Read all the invoice data
        String issuerNameValue = sP.getString("IssuerName", "");
        String buyerNameValue = sP.getString("BuyerName", "");
        String buyerAddressValue = sP.getString("BuyerAddress", "");
        boolean isPaidValue = sP.getBoolean("IsPaid", false);
        String itemNameValue = sP.getString("ItemName", "");
        int itemQuantityValue = sP.getInt("ItemQuantity", 0);
        float itemCostValue = sP.getFloat("ItemCost", 0);

        // Update the UI components
        issuerName.setText(issuerNameValue);
        buyerName.setText(buyerNameValue);
        buyerAddress.setText(buyerAddressValue);
        isPaid.setChecked(isPaidValue);
        itemName.setText(itemNameValue);
        itemQuantity.setText(String.valueOf(itemQuantityValue));
        itemCost.setText(String.format("%.0f", itemCostValue));

        Toast.makeText(this, "Invoice data loaded", Toast.LENGTH_SHORT).show();
    }
}
