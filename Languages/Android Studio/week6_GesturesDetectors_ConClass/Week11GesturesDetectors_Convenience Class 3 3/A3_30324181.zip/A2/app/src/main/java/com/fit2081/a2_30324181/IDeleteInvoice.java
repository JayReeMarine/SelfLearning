package com.fit2081.a2_30324181;

public interface IDeleteInvoice {
    public void onDeleteInvoiceById(int id);
}
